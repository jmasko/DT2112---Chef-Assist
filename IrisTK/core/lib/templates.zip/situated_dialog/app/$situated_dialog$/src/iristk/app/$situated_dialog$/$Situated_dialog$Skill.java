package iristk.app.$situated_dialog$;

import iristk.cfg.SRGSGrammar;
import iristk.flow.Flow;
import iristk.situated.Skill;
import iristk.situated.SkillRequirements;
import iristk.speech.SpeechGrammarContext;
import iristk.util.Language;

public class $Situated_dialog$Skill extends Skill {

	@Override
	public Flow init() throws Exception {
		loadContext("default", new SpeechGrammarContext(new SRGSGrammar(getClass().getResource("$Situated_dialog$Grammar.xml").toURI())));
		setDefaultContext("default");
		return new $Situated_dialog$Flow(getSystemAgentFlow());
	}

	@Override
	public String getName() {
		return "$Situated_dialog$";
	}

	@Override
	public SkillRequirements getRequirements() {
		SkillRequirements requirements = super.getRequirements();
		requirements.requireLanguage(Language.ENGLISH_US);
		requirements.requireSpeechGrammar(true);
		return requirements;
	}
}
